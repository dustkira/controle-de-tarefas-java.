# Controle de Tarefas em Java

Projeto simples de linha de comando para praticar fundamentos de Java.

## Funcionalidades

- Listar tarefas cadastradas
- Adicionar uma tarefa
- Marcar uma tarefa como concluída
- Remover uma tarefa
- Validar entradas numéricas e títulos vazios

## Tecnologias e conceitos

- Java
- `ArrayList` e listas
- Classes e objetos
- Métodos e encapsulamento básico
- Estruturas condicionais e de repetição
- Tratamento de entradas inválidas

## Requisitos

- JDK 17 ou superior

## Como executar

1. Abra o terminal na pasta do projeto.
2. Compile o programa:

   ```bash
   javac Main.java
   ```

3. Execute:

   ```bash
   java Main
   ```

## Próximas melhorias

- Salvar as tarefas em arquivo para que não sejam perdidas ao fechar o programa
- Adicionar data de vencimento e prioridade
- Separar a classe `Tarefa` em um arquivo próprio
- Criar testes automatizados

## Observação

Este é um projeto de estudo. As tarefas ficam apenas na memória durante a execução; ao encerrar o programa, os dados são apagados.
